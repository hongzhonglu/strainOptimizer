# -*- coding: utf-8 -*-
# date : 2023/3/18
# author : wangh
# file : __init__.py.py
# project : strainOptimizer
from .enzyme import genelist_to_enzymelist
